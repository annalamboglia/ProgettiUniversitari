/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/mario/Desktop/progetti_asdi/progetto_6/codice_1/system_a.vhd";
extern char *IEEE_P_1242562249;

int ieee_p_1242562249_sub_1657552908_1035706684(char *, char *, char *);
char *ieee_p_1242562249_sub_1919365254_1035706684(char *, char *, char *, char *, int );


static void work_a_1449575156_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(69, ng0);

LAB3:    t1 = (t0 + 2152U);
    t2 = *((char **)t1);
    t1 = (t0 + 5144);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 4U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 4888);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_1449575156_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(70, ng0);

LAB3:    t1 = (t0 + 2312U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 5208);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 4904);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_1449575156_3212880686_p_2(char *t0)
{
    char t31[16];
    char *t1;
    char *t2;
    char *t3;
    unsigned char t4;
    unsigned char t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned char t10;
    unsigned char t11;
    unsigned char t12;
    unsigned char t13;
    unsigned char t14;
    unsigned char t15;
    char *t16;
    unsigned char t17;
    unsigned char t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    int t25;
    int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    static char *nl0[] = {&&LAB17, &&LAB18, &&LAB19, &&LAB20, &&LAB21};

LAB0:    t1 = (t0 + 4568U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(82, ng0);

LAB6:    t2 = (t0 + 4920);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    t3 = (t0 + 4920);
    *((int *)t3) = 0;
    xsi_set_current_line(84, ng0);
    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t5 = (t4 == (unsigned char)3);
    if (t5 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 992U);
    t5 = xsi_signal_has_event(t2);
    if (t5 == 1)
        goto LAB13;

LAB14:    t4 = (unsigned char)0;

LAB15:    if (t4 != 0)
        goto LAB11;

LAB12:
LAB9:    goto LAB2;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    xsi_set_current_line(86, ng0);
    t2 = (t0 + 5272);
    t6 = (t2 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = (unsigned char)0;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(87, ng0);
    t2 = (t0 + 8972);
    t6 = (t0 + 2968U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t2, 1U);
    goto LAB9;

LAB11:    xsi_set_current_line(91, ng0);
    t3 = (t0 + 1992U);
    t7 = *((char **)t3);
    t12 = *((unsigned char *)t7);
    t3 = (char *)((nl0) + t12);
    goto **((char **)t3);

LAB13:    t3 = (t0 + 1032U);
    t6 = *((char **)t3);
    t10 = *((unsigned char *)t6);
    t11 = (t10 == (unsigned char)3);
    t4 = t11;
    goto LAB15;

LAB16:    goto LAB9;

LAB17:    xsi_set_current_line(96, ng0);
    t8 = (t0 + 1512U);
    t9 = *((char **)t8);
    t14 = *((unsigned char *)t9);
    t15 = (t14 == (unsigned char)3);
    if (t15 == 1)
        goto LAB25;

LAB26:    t13 = (unsigned char)0;

LAB27:    if (t13 != 0)
        goto LAB22;

LAB24:
LAB23:    goto LAB16;

LAB18:    xsi_set_current_line(104, ng0);
    t2 = (t0 + 2848U);
    t3 = *((char **)t2);
    t23 = (15 - 15);
    t24 = (t23 * 1U);
    t2 = (t0 + 2968U);
    t6 = *((char **)t2);
    t2 = (t0 + 8872U);
    t25 = ieee_p_1242562249_sub_1657552908_1035706684(IEEE_P_1242562249, t6, t2);
    t26 = (t25 - 0);
    t27 = (t26 * 1);
    xsi_vhdl_check_range_of_index(0, 1, 1, t25);
    t28 = (16U * t27);
    t29 = (0 + t28);
    t30 = (t29 + t24);
    t7 = (t3 + t30);
    t8 = (t0 + 5336);
    t9 = (t8 + 56U);
    t16 = *((char **)t9);
    t19 = (t16 + 56U);
    t20 = *((char **)t19);
    memcpy(t20, t7, 4U);
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(105, ng0);
    t2 = (t0 + 5400);
    t3 = (t2 + 56U);
    t6 = *((char **)t3);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(106, ng0);

LAB30:    t2 = (t0 + 4936);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB31;
    goto LAB1;

LAB19:    xsi_set_current_line(113, ng0);
    t2 = (t0 + 2848U);
    t3 = *((char **)t2);
    t23 = (15 - 11);
    t24 = (t23 * 1U);
    t2 = (t0 + 2968U);
    t6 = *((char **)t2);
    t2 = (t0 + 8872U);
    t25 = ieee_p_1242562249_sub_1657552908_1035706684(IEEE_P_1242562249, t6, t2);
    t26 = (t25 - 0);
    t27 = (t26 * 1);
    xsi_vhdl_check_range_of_index(0, 1, 1, t25);
    t28 = (16U * t27);
    t29 = (0 + t28);
    t30 = (t29 + t24);
    t7 = (t3 + t30);
    t8 = (t0 + 5336);
    t9 = (t8 + 56U);
    t16 = *((char **)t9);
    t19 = (t16 + 56U);
    t20 = *((char **)t19);
    memcpy(t20, t7, 4U);
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(114, ng0);
    t2 = (t0 + 5400);
    t3 = (t2 + 56U);
    t6 = *((char **)t3);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(115, ng0);

LAB38:    t2 = (t0 + 4968);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB39;
    goto LAB1;

LAB20:    xsi_set_current_line(123, ng0);
    t2 = (t0 + 2848U);
    t3 = *((char **)t2);
    t23 = (15 - 7);
    t24 = (t23 * 1U);
    t2 = (t0 + 2968U);
    t6 = *((char **)t2);
    t2 = (t0 + 8872U);
    t25 = ieee_p_1242562249_sub_1657552908_1035706684(IEEE_P_1242562249, t6, t2);
    t26 = (t25 - 0);
    t27 = (t26 * 1);
    xsi_vhdl_check_range_of_index(0, 1, 1, t25);
    t28 = (16U * t27);
    t29 = (0 + t28);
    t30 = (t29 + t24);
    t7 = (t3 + t30);
    t8 = (t0 + 5336);
    t9 = (t8 + 56U);
    t16 = *((char **)t9);
    t19 = (t16 + 56U);
    t20 = *((char **)t19);
    memcpy(t20, t7, 4U);
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(124, ng0);
    t2 = (t0 + 5400);
    t3 = (t2 + 56U);
    t6 = *((char **)t3);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(125, ng0);

LAB46:    t2 = (t0 + 5000);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB47;
    goto LAB1;

LAB21:    xsi_set_current_line(132, ng0);
    t2 = (t0 + 2848U);
    t3 = *((char **)t2);
    t23 = (15 - 3);
    t24 = (t23 * 1U);
    t2 = (t0 + 2968U);
    t6 = *((char **)t2);
    t2 = (t0 + 8872U);
    t25 = ieee_p_1242562249_sub_1657552908_1035706684(IEEE_P_1242562249, t6, t2);
    t26 = (t25 - 0);
    t27 = (t26 * 1);
    xsi_vhdl_check_range_of_index(0, 1, 1, t25);
    t28 = (16U * t27);
    t29 = (0 + t28);
    t30 = (t29 + t24);
    t7 = (t3 + t30);
    t8 = (t0 + 5336);
    t9 = (t8 + 56U);
    t16 = *((char **)t9);
    t19 = (t16 + 56U);
    t20 = *((char **)t19);
    memcpy(t20, t7, 4U);
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(133, ng0);
    t2 = (t0 + 5400);
    t3 = (t2 + 56U);
    t6 = *((char **)t3);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(134, ng0);

LAB54:    t2 = (t0 + 5032);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB55;
    goto LAB1;

LAB22:    xsi_set_current_line(97, ng0);
    t8 = (t0 + 5272);
    t19 = (t8 + 56U);
    t20 = *((char **)t19);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    *((unsigned char *)t22) = (unsigned char)1;
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(98, ng0);
    t2 = (t0 + 3088U);
    t3 = *((char **)t2);
    t2 = (t3 + 0);
    *((unsigned char *)t2) = (unsigned char)1;
    goto LAB23;

LAB25:    t8 = (t0 + 3088U);
    t16 = *((char **)t8);
    t17 = *((unsigned char *)t16);
    t18 = (!(t17));
    t13 = t18;
    goto LAB27;

LAB28:    t3 = (t0 + 4936);
    *((int *)t3) = 0;
    xsi_set_current_line(107, ng0);
    t2 = (t0 + 5400);
    t3 = (t2 + 56U);
    t6 = *((char **)t3);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(108, ng0);

LAB34:    t2 = (t0 + 4952);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB35;
    goto LAB1;

LAB29:    t3 = (t0 + 1192U);
    t6 = *((char **)t3);
    t4 = *((unsigned char *)t6);
    t5 = (t4 == (unsigned char)3);
    if (t5 == 1)
        goto LAB28;
    else
        goto LAB30;

LAB31:    goto LAB29;

LAB32:    t3 = (t0 + 4952);
    *((int *)t3) = 0;
    xsi_set_current_line(109, ng0);
    t2 = (t0 + 5272);
    t3 = (t2 + 56U);
    t6 = *((char **)t3);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB16;

LAB33:    t3 = (t0 + 1192U);
    t6 = *((char **)t3);
    t4 = *((unsigned char *)t6);
    t5 = (t4 == (unsigned char)2);
    if (t5 == 1)
        goto LAB32;
    else
        goto LAB34;

LAB35:    goto LAB33;

LAB36:    t3 = (t0 + 4968);
    *((int *)t3) = 0;
    xsi_set_current_line(116, ng0);
    t2 = (t0 + 5400);
    t3 = (t2 + 56U);
    t6 = *((char **)t3);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(117, ng0);

LAB42:    t2 = (t0 + 4984);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB43;
    goto LAB1;

LAB37:    t3 = (t0 + 1192U);
    t6 = *((char **)t3);
    t4 = *((unsigned char *)t6);
    t5 = (t4 == (unsigned char)3);
    if (t5 == 1)
        goto LAB36;
    else
        goto LAB38;

LAB39:    goto LAB37;

LAB40:    t3 = (t0 + 4984);
    *((int *)t3) = 0;
    xsi_set_current_line(118, ng0);
    t2 = (t0 + 5272);
    t3 = (t2 + 56U);
    t6 = *((char **)t3);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB16;

LAB41:    t3 = (t0 + 1192U);
    t6 = *((char **)t3);
    t4 = *((unsigned char *)t6);
    t5 = (t4 == (unsigned char)2);
    if (t5 == 1)
        goto LAB40;
    else
        goto LAB42;

LAB43:    goto LAB41;

LAB44:    t3 = (t0 + 5000);
    *((int *)t3) = 0;
    xsi_set_current_line(126, ng0);
    t2 = (t0 + 5400);
    t3 = (t2 + 56U);
    t6 = *((char **)t3);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(127, ng0);

LAB50:    t2 = (t0 + 5016);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB51;
    goto LAB1;

LAB45:    t3 = (t0 + 1192U);
    t6 = *((char **)t3);
    t4 = *((unsigned char *)t6);
    t5 = (t4 == (unsigned char)3);
    if (t5 == 1)
        goto LAB44;
    else
        goto LAB46;

LAB47:    goto LAB45;

LAB48:    t3 = (t0 + 5016);
    *((int *)t3) = 0;
    xsi_set_current_line(128, ng0);
    t2 = (t0 + 5272);
    t3 = (t2 + 56U);
    t6 = *((char **)t3);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)4;
    xsi_driver_first_trans_fast(t2);
    goto LAB16;

LAB49:    t3 = (t0 + 1192U);
    t6 = *((char **)t3);
    t4 = *((unsigned char *)t6);
    t5 = (t4 == (unsigned char)2);
    if (t5 == 1)
        goto LAB48;
    else
        goto LAB50;

LAB51:    goto LAB49;

LAB52:    t3 = (t0 + 5032);
    *((int *)t3) = 0;
    xsi_set_current_line(135, ng0);
    t2 = (t0 + 5400);
    t3 = (t2 + 56U);
    t6 = *((char **)t3);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(136, ng0);

LAB58:    t2 = (t0 + 5048);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB59;
    goto LAB1;

LAB53:    t3 = (t0 + 1192U);
    t6 = *((char **)t3);
    t4 = *((unsigned char *)t6);
    t5 = (t4 == (unsigned char)3);
    if (t5 == 1)
        goto LAB52;
    else
        goto LAB54;

LAB55:    goto LAB53;

LAB56:    t3 = (t0 + 5048);
    *((int *)t3) = 0;
    xsi_set_current_line(138, ng0);
    t2 = (t0 + 1512U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t5 = (t4 == (unsigned char)3);
    if (t5 != 0)
        goto LAB60;

LAB62:
LAB61:    xsi_set_current_line(142, ng0);
    t2 = (t0 + 3088U);
    t3 = *((char **)t2);
    t2 = (t3 + 0);
    *((unsigned char *)t2) = (unsigned char)0;
    xsi_set_current_line(143, ng0);
    t2 = (t0 + 2968U);
    t3 = *((char **)t2);
    t2 = (t0 + 8872U);
    t6 = ieee_p_1242562249_sub_1919365254_1035706684(IEEE_P_1242562249, t31, t3, t2, 1);
    t7 = (t0 + 2968U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    t9 = (t31 + 12U);
    t23 = *((unsigned int *)t9);
    t24 = (1U * t23);
    memcpy(t7, t6, t24);
    xsi_set_current_line(144, ng0);
    t2 = (t0 + 5272);
    t3 = (t2 + 56U);
    t6 = *((char **)t3);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)0;
    xsi_driver_first_trans_fast(t2);
    goto LAB16;

LAB57:    t3 = (t0 + 1192U);
    t6 = *((char **)t3);
    t4 = *((unsigned char *)t6);
    t5 = (t4 == (unsigned char)2);
    if (t5 == 1)
        goto LAB56;
    else
        goto LAB58;

LAB59:    goto LAB57;

LAB60:    xsi_set_current_line(139, ng0);

LAB65:    t2 = (t0 + 5064);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB66;
    goto LAB1;

LAB63:    t6 = (t0 + 5064);
    *((int *)t6) = 0;
    goto LAB61;

LAB64:    t6 = (t0 + 1512U);
    t7 = *((char **)t6);
    t10 = *((unsigned char *)t7);
    t11 = (t10 == (unsigned char)2);
    if (t11 == 1)
        goto LAB63;
    else
        goto LAB65;

LAB66:    goto LAB64;

}


extern void work_a_1449575156_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1449575156_3212880686_p_0,(void *)work_a_1449575156_3212880686_p_1,(void *)work_a_1449575156_3212880686_p_2};
	xsi_register_didat("work_a_1449575156_3212880686", "isim/system_tb_isim_beh.exe.sim/work/a_1449575156_3212880686.didat");
	xsi_register_executes(pe);
}
