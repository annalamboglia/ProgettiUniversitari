/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Users/MarioAgostino/Desktop/Universita/ASDi/Progetti/orologio/codice/intertempi.vhd";
extern char *IEEE_P_2592010699;



static void work_a_2581512285_1181938964_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    xsi_set_current_line(89, ng0);

LAB3:    t1 = (t0 + 2840U);
    t2 = *((char **)t1);
    t3 = (18 - 1);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 5184);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 17U);
    xsi_driver_first_trans_fast_port(t6);

LAB2:    t11 = (t0 + 5088);
    *((int *)t11) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_2581512285_1181938964_p_1(char *t0)
{
    char t10[16];
    char t12[16];
    char *t1;
    char *t2;
    int t3;
    int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    char *t8;
    char *t9;
    char *t11;
    char *t13;
    char *t14;
    int t15;
    unsigned int t16;
    unsigned char t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;

LAB0:    xsi_set_current_line(90, ng0);

LAB3:    t1 = (t0 + 2840U);
    t2 = *((char **)t1);
    t3 = (17 * 2);
    t4 = (t3 + 1);
    t5 = (t4 - 1);
    t6 = (t5 * 1U);
    t7 = (0 + t6);
    t1 = (t2 + t7);
    t8 = (t0 + 2200U);
    t9 = *((char **)t8);
    t11 = ((IEEE_P_2592010699) + 4024);
    t13 = (t12 + 0U);
    t14 = (t13 + 0U);
    *((int *)t14) = 35;
    t14 = (t13 + 4U);
    *((int *)t14) = 51;
    t14 = (t13 + 8U);
    *((int *)t14) = 1;
    t15 = (51 - 35);
    t16 = (t15 * 1);
    t16 = (t16 + 1);
    t14 = (t13 + 12U);
    *((unsigned int *)t14) = t16;
    t14 = (t0 + 8912U);
    t8 = xsi_base_array_concat(t8, t10, t11, (char)97, t1, t12, (char)97, t9, t14, (char)101);
    t16 = (17U + 17U);
    t17 = (34U != t16);
    if (t17 == 1)
        goto LAB5;

LAB6:    t18 = (t0 + 5248);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    memcpy(t22, t8, 34U);
    xsi_driver_first_trans_fast(t18);

LAB2:    t23 = (t0 + 5104);
    *((int *)t23) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(34U, t16, 0);
    goto LAB6;

}


extern void work_a_2581512285_1181938964_init()
{
	static char *pe[] = {(void *)work_a_2581512285_1181938964_p_0,(void *)work_a_2581512285_1181938964_p_1};
	xsi_register_didat("work_a_2581512285_1181938964", "isim/cronometro_tb_isim_beh.exe.sim/work/a_2581512285_1181938964.didat");
	xsi_register_executes(pe);
}
